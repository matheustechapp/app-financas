# Fluxo — Controle Financeiro PWA

App de controle financeiro pessoal, baseado na sua planilha de Fluxo de Caixa.

## Estrutura dos Arquivos

```
fluxo-pwa/
├── index.html     ← App completo
├── manifest.json  ← Configuração do PWA
├── sw.js          ← Service Worker (offline)
├── icon-192.png   ← Ícone 192x192 (adicione você)
└── icon-512.png   ← Ícone 512x512 (adicione você)
```

## Como publicar no GitHub Pages (gratuito)

1. Crie uma conta em https://github.com (se não tiver)
2. Clique em "New repository"
   - Nome: `fluxo-financeiro` (ou qualquer nome)
   - Marque "Public"
   - Clique "Create repository"
3. Clique em "uploading an existing file"
4. Arraste todos os arquivos desta pasta
5. Clique "Commit changes"
6. Vá em Settings → Pages → Source: "main" → Save
7. Seu app estará em: `https://seuusuario.github.io/fluxo-financeiro`

## Como instalar no Android

1. Abra o link no Chrome
2. Toque no menu (⋮) no canto superior direito
3. Toque em "Adicionar à tela inicial"
4. Confirme — o app aparecerá na sua tela como qualquer outro app!

## Funcionalidades

- ✅ Lançamentos de Entrada e Saída
- ✅ Campos: Data, Descrição, Detalhamento, Valor, Categoria, Forma de Pagamento, Responsável
- ✅ Gráfico de pizza por categoria
- ✅ Metas mensais por categoria
- ✅ Lançamentos recorrentes (repetem todo mês)
- ✅ Exportar para CSV (abre no Excel/Google Sheets)
- ✅ Importar CSV (no mesmo formato da sua planilha)
- ✅ Funciona offline (Service Worker)
- ✅ Dados salvos no dispositivo (localStorage)

## Estrutura dos dados (mesma da sua planilha)

| Campo | Descrição |
|-------|-----------|
| Data | Data do lançamento |
| Descrição | Nome do gasto/entrada |
| Detalhamento | Ex: "Parcela 01 de 06" |
| Valor | Valor em R$ |
| Categoria | Saúde, Alimentação, etc. |
| Forma Pgt. | C6, Inter, XP, TAP, Nubank... |
| Responsável | Quem gerou o gasto |
| Classificação | Entrada ou Saída |

## Sincronização em Nuvem (futuro)

Para sincronizar entre dispositivos, será necessário:
- Criar conta no Supabase (https://supabase.com) — gratuito
- Adicionar as credenciais no código (posso fazer isso para você)

Por enquanto, use o botão "Exportar CSV" para fazer backup e o "Importar CSV" para restaurar.
